export interface AccessToken {
  accessToken: string;
}

export const tokenKey = 'msatbossweb$%31';
